﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBHelper
{
    public class DbHelper
    {
        /// <summary>
        /// 连接字符串
        /// </summary>
        public static string ConnectionString;
        private static SqlConnection conn;

        /// <summary>
        /// 初始化连接
        /// </summary>
        public static void InitConn()
        {
            if (conn == null || conn.State != System.Data.ConnectionState.Open)
            {
                conn = new SqlConnection(ConnectionString);
                conn.Open();
            }
        }
        /// <summary>
        /// 查询方法（SELECT语句）
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static DataSet Query(string sql)
        {
            InitConn();
            var ds = new DataSet();
            var adapa = new SqlDataAdapter(sql, conn);
            adapa.Fill(ds);
            return ds;
        }

        /// <summary>
        /// 执行非SELECT语句
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static int ExcuteNonQuery(string sql)
        {
            InitConn();
            var cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteNonQuery();
        }
        public static DataSet newQuery(string sql)
        {
            InitConn();
            //初始化一个内存数据库：DataSet
            var ds = new DataSet();
            //创建查询“适配器”
            var adapter = new SqlDataAdapter(sql, conn);
            //使用适配器从数据库中查询数据并填充到内存数据库中
            adapter.Fill(ds);
            return ds;
        }
    }
}
