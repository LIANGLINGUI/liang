﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebDisk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“administrationDataSet.Users”中。您可以根据需要移动或删除它。
            this.usersTableAdapter.Fill(this.administrationDataSet.Users);

           

            ///子管理显示窗
            
            dataGridView2.AutoGenerateColumns = false;
            
            DBHelper.DbHelper.ConnectionString = "server=.;database=Administration;Integrated Security=True";
            var ds = DBHelper.DbHelper.newQuery("SELECT * FROM Users");
            dataGridView2.DataSource = ds.Tables[0];


        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var frm = new Form2();
            frm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //连接数据库
            DBHelper.DbHelper.ConnectionString = "server=.;database=Administration;Integrated Security=True";
            var ds = DBHelper.DbHelper.Query("SELECT * FROM Users");
            ///接收输入框数据
            var num1 = this.textBox2.Text;
            var num2 = this.textBox3.Text;
            var num = this.textBox1.Text;
            ///验证输入框是否为空
            if (num == "" || num1 == "" || num2 == "")
            {
                MessageBox.Show("输入不能为空！");
            }

            //验证旧密码是否正确
            try
            {
                var passWord = DBHelper.DbHelper.ExcuteNonQuery($"SELECT [password] FROM Users WHERE [password]='{num}'");

                if (num == $"{passWord}")
                {
                    ///验证新密码和确认密码是否一致
                    if (num1 == num2)
                    {
                        ///更新数据
                        var cmd = DBHelper.DbHelper.ExcuteNonQuery($"UPDATE [Users] SET [password]='{textBox2.Text}' WHERE [password]='{textBox1.Text}'");
                        MessageBox.Show("密码修改成功！");
                    }
                    else
                    {
                        MessageBox.Show("确认密码与新密码不一致！");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("密码输入错误！");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
                
         

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
