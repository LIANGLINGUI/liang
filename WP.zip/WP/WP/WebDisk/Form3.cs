﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebDisk
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //获取用户输入的用户名和密码
            string txtName = this.textBox1.Text;
            string txtPwd = this.textBox2.Text;
            //非空验证
            if (txtName == "" || txtPwd == "")
            {
                MessageBox.Show("用户名和密码不能为空！");
            }
            else
            {
                //验证用户名是否匹配
                if (txtName == "admin" && txtPwd == "admin")
                {
                    MessageBox.Show("登陆成功！");
                    Form1 form1 = new Form1();
                    form1.Show();
                }
                else
                {
                    MessageBox.Show("登陆失败！");
                }
            }
        }
    }
}
